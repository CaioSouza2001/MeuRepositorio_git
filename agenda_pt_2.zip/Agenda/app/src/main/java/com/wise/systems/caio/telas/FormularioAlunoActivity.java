package com.wise.systems.caio.telas;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wise.systems.caio.R;
import com.wise.systems.caio.dao.AlunoDAO;
import com.wise.systems.caio.model.Aluno;

import static com.wise.systems.caio.telas.ConstantesActivities.CHAVE_ALUNO;

public class FormularioAlunoActivity extends AppCompatActivity
{
    private static final String APPBAR_LABEL_ADD = "Cadastrar novo aluno";
    private static final String APPBAR_LABEL_UPDATE = "Atualizar Aluno";
    private FloatingActionButton btnCancelar, btnCadastrar;
    private AlunoDAO dao;
    private EditText nome;
    private EditText telefone;
    private EditText email;
    private Aluno aluno;

    public FormularioAlunoActivity()
    {
        dao = new AlunoDAO();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_aluno);
        iniciarComponentes();
        configurarBotaoSalvar();
        configurarBotaoCancelar();

        carregarDadosAluno();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_formulario, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        if(item.getItemId() == R.id.salvar_aluno)
        {
            finalizarFormulario();
            FormularioAlunoActivity.this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void carregarDadosAluno()
    {
        Intent dados = getIntent();
        if(dados.hasExtra(CHAVE_ALUNO))
        {
            aluno = (Aluno) dados.getSerializableExtra(CHAVE_ALUNO);
            nomearActionBar(APPBAR_LABEL_UPDATE);

            preencherCampos();
        }
        else
        {
            nomearActionBar(APPBAR_LABEL_ADD);
            aluno = new Aluno();
        }
    }

    private void nomearActionBar(String appbarLabelUpdate)
    {
        getSupportActionBar().setTitle(appbarLabelUpdate);
    }

    private void preencherCampos()
    {
        nome.setText(aluno.getNome());
        telefone.setText(aluno.getTelefone());
        email.setText(aluno.getEmail());
    }

    private void iniciarComponentes()
    {
        nome = findViewById(R.id.nome_aluno_formulario);
        telefone = findViewById(R.id.telefone_aluno_formulario);
        email = findViewById(R.id.email_aluno_formulario);

        btnCancelar = findViewById(R.id.btn_fab_adicionar_aluno_cancelar);
        btnCadastrar = findViewById(R.id.btn_fab_adicionar_aluno_confirmar);

    }

    private void configurarBotaoCancelar()
    {
        btnCancelar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                FormularioAlunoActivity.this.finish();
            }
        });
    }

    private void configurarBotaoSalvar()
    {
        btnCadastrar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
               // if (validarDados())
                //{
                    finalizarFormulario();
                    FormularioAlunoActivity.this.finish();
               // }
            }
        });
    }

    private void finalizarFormulario()
    {
        preencheAluno();
        if(!aluno.temIdValido())
        {
            dao.salvar(aluno);
        }
        else
        {
            dao.editar(aluno);
        }
    }

    private void preencheAluno()
    {
        String nomeAluno = nome.getText().toString().trim();
        String telefoneAluno = telefone.getText().toString().trim();
        String emailAluno = email.getText().toString().trim();
        aluno.setNome(nomeAluno);
        aluno.setEmail(emailAluno);
        aluno.setTelefone(telefoneAluno);
    }

  /*  private boolean validarDados()
    {
        boolean validacao = true;

        if (nome.getText().toString().trim().isEmpty())
        {
            nome.setError("Informacao obrigatoria!");
            validacao = false;
        }

        if (telefone.getText().toString().trim().isEmpty())
        {
            telefone.setError("Informacao obrigatoria!");
            validacao = false;
        }

        if (email.getText().toString().trim().isEmpty())
        {
            email.setError("Informacao obrigatoria!");
            validacao = false;
        }

        return validacao;
    }*/

}

