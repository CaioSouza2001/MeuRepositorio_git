package com.wise.systems.caio.model;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Aluno implements Serializable
{
    private int id = 0;
    private String nome;
    private String email;
    private String telefone;

    public Aluno()
    {}


   /* public Aluno(String nome, String email, String telefone)
    {
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
    }*/

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getNome()
    {
        return nome;
    }

    public String getEmail()
    {
        return email;
    }

    public String getTelefone()
    {
        return telefone;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public void setTelefone(String telefone)
    {
        this.telefone = telefone;
    }

    @NonNull
    @Override
    public String toString()
    {
        return nome;
    }

    public boolean temIdValido()
    {
        if(id > 0)
        {
            return true;
        }
        return false;
    }
}
