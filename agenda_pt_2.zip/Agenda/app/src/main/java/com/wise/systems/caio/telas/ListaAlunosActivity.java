package com.wise.systems.caio.telas;

import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wise.systems.caio.R;
import com.wise.systems.caio.dao.AlunoDAO;
import com.wise.systems.caio.model.Aluno;

import static com.wise.systems.caio.telas.ConstantesActivities.CHAVE_ALUNO;

public class ListaAlunosActivity extends AppCompatActivity
{
    public static final String AGENDA_WISE = "Agenda Wise";
    private ListView listaAlunos;
    private FloatingActionButton btnFormulario;
    private AlunoDAO alunoDAO;
    private ArrayAdapter<Aluno> adapter;

    public ListaAlunosActivity()
    {
        alunoDAO = new AlunoDAO();
    }


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        getSupportActionBar().setTitle(AGENDA_WISE);
        setContentView(R.layout.activity_lista_alunos);

        iniciarLista();
        configurarLista();
        configurarBotaoAddAluno();

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo)
    {
        super.onCreateContextMenu(menu, v, menuInfo);

        getMenuInflater().inflate(R.menu.menu_listview, menu);
        // menu_listview.add("Remover");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item)
    {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        Aluno alunoEscolhido = adapter.getItem(info.position);
        if (item.getItemId() == R.id.remover_aluno)
        {
            removerAlunoDaLista(alunoEscolhido);
        }
        else if (item.getItemId() == R.id.atualizar_aluno)
        {
            abrirFormularioModoEditarAluno(alunoEscolhido);
        }

        return super.onContextItemSelected(item);
    }

    private void iniciarLista()
    {
        listaAlunos = findViewById(R.id.lista_alunos);
    }

    private void configurarBotaoAddAluno()
    {
        btnFormulario = findViewById(R.id.btn_fab_adicionar_aluno);
        btnFormulario.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(ListaAlunosActivity.this, FormularioAlunoActivity.class);
                irParaFormulario(intent);
            }
        });
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        atualizarListaAlunos();
    }

    private void atualizarListaAlunos()
    {
        adapter.clear();
        adapter.addAll(alunoDAO.todos());
    }

    private void configurarLista()
    {

        configurarAdapter(listaAlunos);
        registerForContextMenu(listaAlunos);
    }

    private void removerAlunoDaLista(Aluno aluno)
    {
        alunoDAO.remover(aluno);
        adapter.remove(aluno);
    }

    private void abrirFormularioModoEditarAluno(Aluno aluno)
    {
        Intent abrirFormularioPreenchido = new Intent(ListaAlunosActivity.this, FormularioAlunoActivity.class);
        abrirFormularioPreenchido.putExtra(CHAVE_ALUNO, aluno);
        irParaFormulario(abrirFormularioPreenchido);
    }

    private void configurarAdapter(ListView listaAlunos)
    {
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listaAlunos.setAdapter(adapter);
    }

    private void irParaFormulario(Intent intent)
    {
        startActivity(intent);
    }


}
