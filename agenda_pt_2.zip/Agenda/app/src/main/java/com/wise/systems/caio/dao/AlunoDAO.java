package com.wise.systems.caio.dao;

import com.wise.systems.caio.model.Aluno;

import java.util.ArrayList;
import java.util.List;

public class AlunoDAO
{
    private final static List<Aluno> alunos = new ArrayList<>();
    private static int CONTADOR_IDS = 1;

    public void salvar(Aluno aluno)
    {
        aluno.setId(CONTADOR_IDS);
        alunos.add(aluno);
        atualizarIds();
    }

    private void atualizarIds()
    {
        CONTADOR_IDS++;
    }

    public List<Aluno> todos()
    {
        return new ArrayList<>(alunos);
    }

    public void editar(Aluno aluno)
    {
        Aluno alunoEncontrado = buscarAlunoPorId(aluno);
        if (alunoEncontrado != null)
        {
            int posicaoAluno = alunos.indexOf(alunoEncontrado);
            alunos.set(posicaoAluno, aluno);
        }
    }

    private Aluno buscarAlunoPorId(Aluno aluno)
    {
        for (Aluno aluno2 : alunos)
        {
            if (aluno2.getId() == aluno.getId())
            {
                return aluno2;
            }
        }
        return null;
    }


    public void remover(Aluno aluno)
    {
        Aluno alunoDevolvido = buscarAlunoPorId(aluno);

        if (alunoDevolvido != null)
        {
            alunos.remove(alunoDevolvido);

        }
    }
}
