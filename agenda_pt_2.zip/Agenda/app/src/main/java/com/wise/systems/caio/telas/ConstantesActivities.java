package com.wise.systems.caio.telas;

public interface ConstantesActivities
{
   String CHAVE_ALUNO = "aluno";

}
